<?php
	session_start();
	if(isset($_SESSION["id"])){
		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>LONGPORT</title>
	
	<link rel="stylesheet" type="text/css" href="plugins/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="plugins/font-awesome/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="plugins/select2/css/select2.min.css" />
	<link rel="stylesheet" type="text/css" href="plugins/select2/css/select2-bootstrap.css" />
	
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
	<script type="text/javascript" src="plugins/jquery/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="plugins/jquery/jquery.number.js"></script>
	<script type="text/javascript" src="plugins/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="plugins/select2/js/select2.full.js"></script>
	<script type="text/javascript" src="plugins/bootbox/bootbox.min.js"></script>
	
	<script type="text/javascript" src="js/generales.js"></script>
	
</head>
<body onload="javascript: load_form_login()">
	
</body>
</html>