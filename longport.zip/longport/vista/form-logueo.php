<div class="col-md-12" id="d-form-logueo">
	<div class="col-md-12" align="center">
		<h4>Formulario de Creación</h4>
	</div>
	<form onsubmit="return false" id="f-logueo">
		<div class="col-md-12">
			<div class="form-group">
				<label>Email</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-email"><i class="fa fa-envelope fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="text" class="form-control input-lg" id="i-email" name="email" placeholder="email" />
				</div>
			</div>
			<div class="form-group">
				<label>Contraseña</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-password"><i class="fa fa-unlock-alt fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="password" class="form-control input-lg" id="i-password" name="password" placeholder="Contraseña" />
				</div>
			</div>
		</div>
		<div class="col-md-12" align="center">
			<button type="submit" class="btn btn-primary btn-lg" onclick="javascript: submit_form_logueo()">Iniciar Sesión</button>
		</div>
	</form>
	<div class="col-md-12" id="errors">
		
	</div>
</div>