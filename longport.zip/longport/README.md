# universidad
Aplicación web que consulta, crea, elimina y actualiza información de estudiantes de una universidad

Todo el proceso de conexión, inserción, consultas.. lo utilizo con una clase creada en el archivo CRUD.php que se encuentra dentro de la carpeta controller; Desde esa clase se hacen los procesos principales de un CRUD.

Para el Frontend utilizo la libreria Bootstrap.
