<link rel="stylesheet" type="text/css" href="../plugins/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="../plugins/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="../plugins/tooltipster/dist/css/tooltipster.bundle.min.css" />
<link rel="stylesheet" type="text/css" href="../plugins/tooltipster/dist/css/plugins/tooltipster/sideTip/themes/tooltipster-sideTip-shadow.min.css" />
<link rel="stylesheet" href="../plugins/select2/css/select2.min.css" />
<link rel="stylesheet" href="../plugins/select2/css/select2-bootstrap.css" />

<script type="text/javascript" src="../plugins/jquery/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="../plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../plugins/tooltipster/dist/js/tooltipster.bundle.min.js"></script>
<script type="text/javascript" src="../plugins/select2/js/select2.full.js"></script>
<script type="text/javascript" src="../plugins/bootbox/bootbox.min.js"></script>