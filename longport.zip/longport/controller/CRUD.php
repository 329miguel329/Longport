<?php
	class CRUD{
		protected $conn;
		public $results;
		public function __construct($host, $port, $dbname, $user, $pass){
			$this -> conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$pass");
		}
		
		public function Select($sql){
			$query = pg_query($this -> conn, $sql);
			if ($query){
				$this->results = array();
				while($datos = pg_fetch_assoc($query)){
					array_push($this -> results, $datos);
				}
				$num = pg_num_rows($query);
				pg_free_result($query);
				return array("num_results" => $num, "results" => $this -> results);
			}else{
				return array("error" => pg_last_error($this -> conn));
			}
		}
		
		public function Insert($sql){
			$query = pg_query($this -> conn, $sql);
			if ($query){
				return array("afected_rows" => pg_affected_rows($query), "last_insert" => pg_last_oid($query));
			}else{
				return array("error" => pg_last_error($this -> conn));
			}
		}
		
		public function UpdateDelete($sql){
			$query = pg_query($this -> conn, $sql);
			if ($query){
				return array("afected_rows" => pg_affected_rows($query));
			}else{
				return array("error" => pg_last_error($this -> conn));
			}
		}
		
		public function __destruct(){
			pg_close($this -> conn);
		}
	}
?>