<?php
	require_once('CRUD.php');
	
	$host = "localhost";
	$port = "5432";
	$user = "postgres";
	$pass = "123";
	$database_name = "LONGPORT";
	$conn = new CRUD($host, $port, $database_name, $user, $pass);
?>