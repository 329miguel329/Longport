<?php
	if (!isset($_SESSION)){
		session_start();
	}
	require_once("../controller/conection.php");
	$consult = $conn -> Select("SELECT u.id id_us, u.nombre nombre, u.apellido apellido, u.email email, u.identificacion identificacion, u.avatar avatar
								FROM public.user u
								WHERE u.id=" . ($_GET["id_div"] / $_SESSION["id_divs"]));
	if(isset($consult["error"])){
		die ($consult["error"]);
	}
?>
<div class="col-md-12" id="d-form-update-user">
	<div class="col-md-12" align="center">
		<h4>Formulario de Actualización</h4>
	</div>
	<form onsubmit="return false" id="f-update-user">
		<div class="col-md-12">
			<div class="form-group">
				<label>Nombre</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-nombre"><i class="fa fa-address-card fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="text" class="form-control input-lg" id="i-nombre"  name="nombre" value="<?php echo $consult["results"][0]["nombre"]; ?>" />
				</div>
			</div>
			<div class="form-group">
				<label>Apellido</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-apellido"><i class="fa fa-address-card fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="text" class="form-control input-lg" id="i-apellido"  name="apellido" value="<?php echo $consult["results"][0]["apellido"]; ?>" />
				</div>
			</div>
			<div class="form-group">
				<label>Email</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-email"><i class="fa fa-envelope fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="text" class="form-control input-lg" id="i-email" name="email" value="<?php echo $consult["results"][0]["email"]; ?>" />
				</div>
			</div>
			<div class="form-group">
				<label>Contraseña</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-password"><i class="fa fa-unlock-alt fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="password" class="form-control input-lg" id="i-password" name="password" placeholder="Contraseña" />
				</div>
			</div>
			<div class="form-group">
				<label>Identificación</label>
				<div class="input-group">
					<span class="input-group-addon" id="sp-identificacion"><i class="fa fa-id-card fa-2x fa-fw" aria-hidden="true"></i></span>
					<input type="text" class="form-control input-lg" id="i-identificacion" name="identificacion" value="<?php echo $consult["results"][0]["identificacion"]; ?>" />
				</div>
			</div>
		</div>
		<div class="col-md-12" align="center">
			<button id="<?php echo $_GET["id_div"]; ?>" type="submit" class="btn btn-primary btn-lg" onclick="javascript: submit_form_updateUser(this.id)">Actualizar estudiante</button>
		</div>
	</form>
	<div class="col-md-12" id="errors">
		
	</div>
</div>
<script>
	$('#i-identificacion').number( true, 0 );
</script>