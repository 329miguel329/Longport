<?php
	require_once("conection.php");
	if (!isset($_SESSION)){
		session_start();
	}
	if(isset($_GET)){
		$sql = "UPDATE public.user SET nombre='" . $_GET["nombre"] . "', apellido='" . $_GET["apellido"] . "', email='" . $_GET["email"] . "', identificacion='" . $_GET["identificacion"] . "', avatar='" . $_GET["avatar"] . "', password='" . sha1($_POST["password"]) . "' WHERE id=" . ($_GET["id_us"] / $_SESSION["id_divs"]);
		$insert = $conn -> UpdateDelete($sql);
		if(isset($insert["error"])){
			echo $insert["error"];
		}else{
			echo 1;
		}
	}else{
		echo "ERROR...";
	}
?>