/*
Función que carga los formularios por medio de ajax dependiendo del llamado
*/
function load_form(url, id_div, nform){
	var dialog = bootbox.dialog({
		message: '<p style="text-align: center; font-size: 50px"><i class="fa fa-spin fa-spinner"></i> Loading form...</p>',
		size:'large',
		onEscape: true,
		backdrop: true,
		closeButton: true
	})
	dialog.init(function(){
		setTimeout(function(){
			$.ajax({
				url: "vista/" + url, 
				cache:false,
				beforeSend:function(){
					dialog.find('.bootbox-body').html('<p style="text-align: center; font-size: 50px"><i class="fa fa-spin fa-spinner"></i> Loading form...</p>');
				},
				type:'GET',
				dataType: "html",
				data: "id_div=" + id_div,
				success: function(data){
					dialog.find('.bootbox-body').html(data);
					$(".bootbox-body").height($("#d-form-" + nform).height());
					
					if(nform == "update-user" || nform == "create-user"){
						$("#i-edad").number(true);
					}
				},
				error:function (a, b, c){
					dialog.find('.bootbox-body').html('<p> Your form could not be loaded. Close and try again.</p>');					
				}		
			});
		}, 1000);
	});
}


function load_form_login(){
	var dialog = bootbox.dialog({
		message: '<p style="text-align: center; font-size: 50px"><i class="fa fa-spin fa-spinner"></i> Loading form...</p>',
		size:'large'
	})
	dialog.init(function(){
		setTimeout(function(){
			$.ajax({
				url: "vista/form-logueo.php",
				cache:false,
				beforeSend:function(){
					dialog.find('.bootbox-body').html('<p style="text-align: center; font-size: 50px"><i class="fa fa-spin fa-spinner"></i> Loading form...</p>');
				},
				type:'GET',
				dataType: "html",
				success: function(data){
					dialog.find('.bootbox-body').html(data);
					$(".bootbox-body").height($("#d-form-logueo").height());
				},
				error:function (a, b, c){
					dialog.find('.bootbox-body').html('<p> Your form could not be loaded. Close and try again.</p>');					
				}		
			});
		}, 1000);
	});
}
/*
Funcion que obtiene los datos de un determinado formulario
Retorna un array con los datos del formulario en formato get y en formato array u objeto
*/
function get_form_data(id_form){
	$("#f-" + id_form + " :input[form-data=form]").each(function(){
		$(this).val($.trim($(this).val()).replace(/(\n)/g,"<br />"));
	});
	return [$("#f-" + id_form).serialize(), $("#f-" + id_form).serializeArray()];
}

function validateEmail(email) {
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test(email);
}

function submit_form_logueo(){
	var data = get_form_data("logueo");
	console.log(data);
	var form_vacio = false;
	for(i in data[1]){
		if(data[1][i].value == "" || data[1][i].value == 0){
			form_vacio = true;
			break;
		}
	}
	if(form_vacio){
		alert("Digite todos los campos");
	}else{
		if(validateEmail($("#i-email").val())){
			$.ajax({
				url:"controller/loguear.php",
				cache:false,
				type:'GET',
				data: data[0],
				beforeSend:function(){
					$("#cargando").show();
				},
				success: function(data){
					console.log(data);
					if(data == 1){
						window.location.href = 'index.php';
					}else{
						mostrar_alert(data);
						$("#cargando").hide();
					}
				},
				error:function (a, b, c){
					console.log(a);
					console.log(b);
					console.log(c);
				}
			});
		}else{
			alert("El email es incorrecto");
		}
	}
}

/*
función que se ejecuta al oprimir el botón del formulario de creación de un nuevo usuario
En esta funcion se verifica si hay algún campo en blanco.
si todos los campos estan bien digitados se implementa el codigo ajax para hacer la inserción de los nuevos datos
*/
function submit_form_createUser(){
	var formData = new FormData($("#f-create-user")[0]);
	var data = get_form_data("create-user");
	var form_vacio = false;
	for(i in data[1]){
		if(data[1][i].value == "" || data[1][i].value == 0){
			form_vacio = true;
			break;
		}
	}
	if(form_vacio){
		alert("Digite todos los campos");
	}else{
		if(validateEmail($("#i-email").val())){
			$.ajax({
				url:"controller/crear_usuario.php",
				cache:false,
				type:'POST',
				data: formData,
				contentType: false,
				processData: false,
				beforeSend:function(){
					$("#cargando").show();
				},
				success: function(data){
					console.log(data);
					if(data == 1){
						mostrar_alert("Creación Exitosa","","color: green; font-size: 25px;");
						window.location.href = 'index.php';
					}else{
						mostrar_alert(data);
						$("#cargando").hide();
					}
				},
				error:function (a, b, c){
					console.log(a);
					console.log(b);
					console.log(c);
				}
			});
		}else{
			alert("El email es incorrecto");
		}
	}
}

/*
Funcion que muestra mensajes con la libreria bootbox
*/
function mostrar_alert(message, time, style){
	var time = time || 2000;
	var style = style || "color: red; font-size: 25px;";
	var alert_message = bootbox.dialog({
		message: '<p class="text-center" style="' + style + '">' + message + '</p>',
		closeButton: false
	});
	
	setTimeout(function(){
		alert_message.modal('hide');
	}, time);
}

/*
función que se ejecuta al oprimir el botón del formulario de actualización de un nuevo usuario
En esta funcion se verifica si hay algún campo en blanco.
si todos los campos estan bien digitados se implementa el codigo ajax para hacer la actualización de los nuevos datos
*/
function submit_form_updateUser(id_us){
	var data = get_form_data("update-user");
	var form_vacio = false;
	for(i in data[1]){
		if(data[1][i].value == "" || data[1][i].value == 0){
			form_vacio = true;
			break;
		}
	}
	if(form_vacio){
		alert("Digite todos los campos");
	}else{
		if(validateEmail($("#i-email").val())){
			$.ajax({
				url:"controller/actualizar_usuario.php",
				cache:false,
				type:'GET',
				data: "id_us=" + id_us + "&" + data[0],
				beforeSend:function(){
					$("#cargando").show();
				},
				success: function(data){
					if(data == 1){
						mostrar_alert("Actualización Exitosa","","color: green; font-size: 25px;");
						setTimeout(function(){location.reload()},2000);
					}else{
						mostrar_alert(data);
					}
				},
				error:function (a, b, c){
					console.log(a);
					console.log(b);
					console.log(c);
				}
			});
		}else{
			alert("email incorrecto");
		}
	}
}

/*
Funcion que se ejecuta al oprimir el boton de eliminación de un usuario.
Esta función pide la confirmación del usuario para eliminar algún usuario
*/
function confirm_delete(id_us){
	bootbox.confirm({
		message: "Desea eliminar este usuario?",
		buttons: {
			confirm: {
				label: 'SI',
				className: 'btn-success'
			},
			cancel: {
				label: 'NO',
				className: 'btn-danger'
			}
		},
		callback: function (result) {
			if(result){
				$.ajax({
					url:"controller/eliminar_usuario.php",
					cache:false,
					type:'GET',
					data: "id_us=" + id_us,
					beforeSend:function(){
						$("#cargando").show();
					},
					success: function(data){
						if(data == 1){
							mostrar_alert("Eliminación Exitosa","","color: green; font-size: 25px;");
							setTimeout(function(){location.reload()},2000);
						}else{
							mostrar_alert(data);
						}
					},
					error:function (a, b, c){
						console.log(a);
						console.log(b);
						console.log(c);
					}
				});
			}
		}
	});
}