<?php
	require_once("conection.php");
	if (!isset($_SESSION)){
		session_start();
	}
	if(isset($_GET)){
		$consult = $conn -> Select("SELECT * FROM public.user WHERE email='" . $_GET["email"] . "' AND password='" . sha1($_GET["password"]) . "'");
		if(isset($consult["error"])){
			echo $consult["error"];
		}else{
			if($consult["num_results"] > 0){
				$_SESSION["id"] = $consult["results"][0][id];
				echo 1;
			}else{
				//echo "Usuario o contraseña incorrecta" . $consult["num_results"];
				echo json_encode($_GET, JSON_FORCE_OBJECT);
			}
		}
	}
?>