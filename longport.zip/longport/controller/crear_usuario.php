<?php
	require_once("conection.php");
	if (!isset($_SESSION)){
		session_start();
	}
	if(isset($_POST)){
		$file = $_FILES["file"];
		$consult = $conn -> Select("SELECT max(id) FROM public.user");
		$tmp_name = $file["tmp_name"];
		$tipo = $file["type"];
		$ruta_provisional = "C:\Program Files (x86)\PostgreSQL\EnterpriseDB-ApachePHP\apache\www\longport\avatar\avatar-" . ($consult["results"][0]["max"] + 1) . "." . array_pop(explode("/",$tipo));
		$avatar = "avatar/avatar-" . ($consult["results"][0]["max"] + 1) . "." . array_pop(explode("/",$tipo));
		$carpeta = "imagenes/";

		if ($tipo != 'image/jpg' && $tipo != 'image/jpeg' && $tipo != 'image/png' && $tipo != 'image/gif'){
		  echo "Error, el archivo no es una imagen";
		}else{
			$src = $carpeta.$nombre;
			if(move_uploaded_file($tmp_name, $ruta_provisional)){
				$sql = "INSERT INTO public.user VALUES(" . ($consult["results"][0]["max"] + 1) . ",'" . $_POST["email"] . "','" . $_POST["nombre"] . "', '" . $_POST["apellido"] . "', '" . $avatar . "', '" . $_POST["identificacion"] . "', '" . sha1($_POST["password"]) . "')";
				$insert = $conn -> Insert($sql);
				if(isset($insert["error"])){
					echo $insert["error"];
				}else{
					echo 1;
				}
			}else{
				echo "Error subiendo archivo";
			}
		}
	}else{
		echo "ERROR...";
	}
?>